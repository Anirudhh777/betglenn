<?php $__env->startSection('front-page'); ?>

<div class="container">
	<a href="<?php echo e(url('/generate_game_week')); ?>">Generate Game Week</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bethelp/resources/views/home.blade.php ENDPATH**/ ?>