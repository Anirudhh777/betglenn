<?php $__env->startSection('front-page'); ?>


<div class="container">
	<div class="results">
		<?php $__currentLoopData = $accums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="accums">
				<?php $__currentLoopData = $accum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="match">
						<div class="level" id="<?php echo e($data['level']); ?>">
							<?php echo e($data['level']); ?>

						</div>
						<div class="match_info">
							<p><?php echo e($data['match']); ?></p>
						</div>
						
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bethelp/resources/views/results.blade.php ENDPATH**/ ?>